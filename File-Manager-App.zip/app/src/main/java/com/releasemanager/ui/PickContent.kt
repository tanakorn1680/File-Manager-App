package com.releasemanager.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContract

/**
 * File picker that behaves like a web page's "choose file": ACTION_GET_CONTENT inside the system chooser, so
 * every app that can hand out a file is offered (Photos, Drive, file managers, Termux, MT Manager, ZArchiver…).
 * OPEN_DOCUMENT, which this replaces, only lists storage providers and so shows far fewer apps.
 * Input is the MIME type (e.g. "*&#47;*"); the result is the picked files, empty when cancelled.
 */
class PickContent(private val multiple: Boolean) : ActivityResultContract<String, List<Uri>>() {

    override fun createIntent(context: Context, input: String): Intent {
        val get = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = input
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
        }
        return Intent.createChooser(get, null)
    }

    override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> {
        if (resultCode != Activity.RESULT_OK || intent == null) return emptyList()
        val clip = intent.clipData
        if (clip != null && clip.itemCount > 0) {
            return (0 until clip.itemCount).mapNotNull { clip.getItemAt(it).uri }
        }
        return listOfNotNull(intent.data)
    }
}
